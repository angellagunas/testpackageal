# -*- coding: utf-8 -*-

class Utils(object):
    def __init__(self):
        print 'some'
    
    @classmethod
    def print_name(name="al"):
        print name
