def print_name(name="al"):
    print name
